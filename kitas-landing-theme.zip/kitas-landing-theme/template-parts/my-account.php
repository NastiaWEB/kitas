<?php
/**
 * Template name: My Account
 */
get_header(); ?>


<?php
get_footer();
